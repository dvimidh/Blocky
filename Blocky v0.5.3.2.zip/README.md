

<img width="1920" height="1111" alt="2025-09-03_15 39 09" src="https://github.com/user-attachments/assets/24ac9502-eaed-4497-90ec-fe7fea702824" />




# **Blocky**

A vanilla inspired shader for Minecraft Java

Feature include:
- Shadows
- Colored Shadows
- Distant Horizon Support
- Basic PBR Support (RP Required, Normals and Specular)
- Anti Aliasing (FXAA, Used with permission from Capt Tatsu's BSL)
- Height Based Analytical Fog (from Inigo Quilez's article on fog)
- Waving Tree Leaves and Water
- Bloom
- Hardcoded Emmissives (More Coming Soon)




